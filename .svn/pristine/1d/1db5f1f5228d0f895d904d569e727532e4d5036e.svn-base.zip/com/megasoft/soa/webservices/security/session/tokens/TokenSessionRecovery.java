package com.megasoft.soa.webservices.security.session.tokens;



import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.megasoft.soa.webservices.commom.WSProperties;
import com.megasoft.utilities.DBOServices;




/*

* Implementa la obtenci�n de la Credencial del Usuario a trav�s del m�todo

* getCredential, el cual, retorna el objeto TokenCredentialBean con toda la

* informaci�n asociada al userID correspondiente.

*/



public class TokenSessionRecovery

{

	//Logger

	private static final Log log = LogFactory.getLog(TokenSessionRecovery.class);

	

	private static DataSource dso = null;

	

	/* 

	 * Retorna las Credenciales del Usuario a trav�s del Objeto TokenCredentialBean

	 * */

	public boolean isAllowed(String userID, String serviceName, String operationName, String ip) throws Exception

	{


		String sql = null;

		

    	//Credenciales del Usuario
   	

		Connection        con = null;

		PreparedStatement st  = null;

		ResultSet         rs  = null;



		try

		{

	    	log.info("Verificaci�n de Acceso a Usuario:" + userID );

	

			//Local Cache de Datasource

			if (dso==null) dso = DBOServices.getDataSource( WSProperties.getProperty("security-access-jndi") );



			sql = WSProperties.getProperty("soa-ws-msc-access");

			

			//Obtiene la conexi�n a Base de Datos

			con = dso.getConnection();

	

		    st = con.prepareStatement(sql,ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);

		    

		    // Asigna el Usuario a validar. No importa si esta activo o Inactivo. Esto es validado posteriormente

			st.setString(1, userID );

			st.setString(2, serviceName );

			st.setString(3, operationName );

			st.setString(4, ip.substring(9));
			
	

			//Ejecuta SQL
				
			
			rs = st.executeQuery();	
			


			if (rs!=null && rs.next())

			{

				log.info("Usuario '" + userID + "' Autorizado.");

				return true;		

			}

			

			//Registra en Log la incidencia

			else

			{

				log.error("Usuario '" + userID + "' No Autorizado.");

				log.info("WS-Security Handler: Acceso No Autorizado desde IP:" + ip  + "Services: " + serviceName  + " OrdenOperacion: "+  operationName + " Usuario: " +  userID );

				return false;

			}

			

		}

		catch(Exception ex)

		{

			ex.printStackTrace();

			String msg = "Excepci�n validando acceso del Usuario '" + userID + "' SQL[" + sql + "]. " + ex.getMessage();

			

			log.error( msg , ex);

			

			//Registra en Log la incidencia

			//WSLogTransaction.setLog( msg );

			

			return false;

		}

        finally

        {

            if ( rs != null ) rs.close();

            if ( st != null ) st.close();

            if ( con!= null ) con.close();

        }

		

	}	

}