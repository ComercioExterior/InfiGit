
package com.megasoft.soa.webservices.logger.error;

import java.sql.Timestamp;

import org.apache.log4j.Logger;

import com.megasoft.soa.webservices.commom.WSProperties;
import com.megasoft.utilities.DBOServices;

  
/*
* Graba en Base de Datos informaci�n pertinente a errores en un servicio web.
* @author Gabriell Calatrava
*/
public class WSLogSoapFault
{
	
	//Logger
	static Logger log = Logger.getLogger( WSLogSoapFault.class );
	
	/*
	 * Determina si el Logs de SoapFault esta activo o inactivo.
	 * Valores a retornar: true (Activo) , false (inactivo)
	 * */
	public static boolean isEnabled() throws Exception
	{
		//Retorna del repositorio de propiedades
		//el valor de la Propiedad que activa (true) o inactiva (false)
		// el Log de Errores.
		return WSProperties.getPropertyBoolean("log-error-enabled");
	
	}
	
	/*
	 * Guarda registro de SoapFault en base de datos indicando Nombre del Servicio, Operaci�n y Mensaje
	 * */
	public static void setLog (String id,  String description, String serviceName, String operationName , String canalName, String stackTrace ) throws Exception 
	{
		try 
		{
 
			//Si esta habilidado el Log Se guarda la traza
			if ( isEnabled() )
			{
				if (id==null)
					id="N/A";
		
				if (description==null)
					description="N/A";
					
				
				if (canalName==null)
					canalName="N/A";
				
				if (serviceName==null)
					serviceName="N/A";
				
				if (operationName==null)
					operationName="N/A";
				
				if (stackTrace==null)
					stackTrace="N/A";
						
				
				log.info("Log de Errores Activo. Message:" + description );
				
				//Obtiene el DataSource definido como propiedad
				String sql = WSProperties.getProperty("log-error-insert");
				String dsName = WSProperties.getProperty("log-error-jndi");
				
				// Trunca los campos si son superiores a la definicion en la tabla
				if (stackTrace.length()>=4000)
					stackTrace= "TRUNCATE:" +stackTrace.substring(0, 3991);
				
				if (description.length()>=4000)
					description= "TRUNCATE:" +description.substring(0, 3991);

				if (serviceName.length()>=50)
					serviceName= "TRUNCATE:" +serviceName.substring(0, 41);

				if (operationName.length()>=50)
					operationName= "TRUNCATE:" +operationName.substring(0, 41);

				if (canalName.length()>=50)
					canalName= "TRUNCATE:" +canalName.substring(0, 41);

				Object[] data = new Object[7];
				data[0] = id;
				data[1] = description;
				data[2] = stackTrace;
				data[3] = canalName;
				data[4] = serviceName;
				data[5] = operationName;
				data[6] = new Timestamp(System.currentTimeMillis());
				DBOServices.executeUpdate(dsName, sql, data);
			}
			//Log no activo
			else
			{
				log.info("Log de Errores Inactivo. Message:" + description );
			}
		}
		catch(Throwable e)
		{
			log.fatal("Excepci�n tratando de registrar un 'Soap Fault' en el Log. Servicio[" + serviceName + "] operationName=[" + operationName + "] message[" + description + "]. " , e);
			
		}
		
	}

    
    
}