package com.megasoft.soa.webservices.security.authentication.tokens;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/*
* Ejecuta todo el proceso de validaci�n de credenciales basados en Tokens (Usuario y Contrase�a)
*/

public class TokenCredentialEngine
{
	//Logger
	private static final Log log = LogFactory.getLog(TokenCredentialEngine.class);
	
	/*
	 * Obtiene el Objeto que representa las credenciales del Usuario Usuario especificado
	 * La obtenci�n de las credenciales implica el siguiente Proceso:
	 *   1.- Se busca la credencial en el cache de credenciales (TokenCredentialRepository)
	 *   2.- De encontrarse la credencial se Retorna la misma. Fin.
	 *   3.- De no encontrarse la credencial en el repositorio, TokenCredentialBean busca las misma en el repositorio Permanente (BD, TXT)
	 *   4.- TokenCredentialValidator verifica si la credencial es v�lida
	 *   5.- De no ser v�lida la credencial se retorna NULL. Fin
	 *   6.- De ser V�lida la credencial se guarda en el repositorio TokenCredentialRepository
	 *   7.- Se retorna la credencial v�lida. Fin.
	 * */
	public TokenCredentialBean getCredential(String userID) throws Exception
	{
		
		TokenCredentialRepository credentialRepository = new TokenCredentialRepository();
		if ( !credentialRepository.isCredentialStored(userID) )
		{
			log.info( "Credential Not found in repository for UserID = " + userID );
				
			//Instancia Componente para recuperaci�n de Credenciales
			TokenCredentialRecovery tr = new TokenCredentialRecovery();
			
			//Recupera las credenciales del Usuario		
			TokenCredentialBean userCredential = tr.getCredential(userID) ;
			log.info( "Credential Recovered for UserID '" + userID + "'  Active '" + userCredential.getUserActive() +"'" ) ;

			log.info( "Validation Process: Validating UserID=" + userID );
			//Instancia Componente para Validaci�n de Credenciales
			TokenCredentialValidator tv = new TokenCredentialValidator();
			
			boolean validCredential = tv.isCredentialValid( userCredential );
			log.info( "Validation Process: Validated UserID '" + userID + "': " + validCredential);

			//Se genera una excepci�n de no ser v�lida la credencial
			if ( !validCredential )
			{
				log.info("Credencial No V�lida para el Usuario.'" + userID + "'");
				return null;
			}

			log.info( "Credential OK: Stored in Repository for UserID '" + userID + "' Status:" + validCredential);
			//Se crea la sesi�n para el UserID Correspondiente.
			credentialRepository.addCredential(userCredential);
			
			//Retorna la Credencial
			return userCredential;
		}
		else
		{
			//Credencial encontrada en repositorio
			log.info( "Session Process: Active Session for UserID = " + userID );
			return credentialRepository.getCredential( userID );
		}
	}	
}