package com.megasoft.soa.webservices.security.session.tokens;

import java.util.Hashtable;

public class TokenSessionBean
{
	
	//Key
	private String       key                     = null;
	
	// Identificaci�n del Usuario
	private String       userID                  = null;
	
	
	//TS de creaci�n de la sesion
	private long         userSessionTimeCreation = 0;
	
	//Session ID
	private String       cookieID                = null;
	
	// Propiedades del particulares de la sesi�n
	private Hashtable    userProperties  = new Hashtable();
	
	//SET's
	public void setKey(String key)
	{
		this.key = key;
	}	


	public void setUserID(String userID)
	{
		this.userID = userID;
	}

	public void setUserSessionTimeCreation(long userSessionTimeCreation)
	{
		this.userSessionTimeCreation = userSessionTimeCreation;
	}	
	
	@SuppressWarnings("unchecked")
	public void setUserProperty(String key, String value) throws Exception
	{
		if (key!=null && value!=null)
			this.userProperties.put (key , value);
	}
	
	public void setCookieID(String cookieID) throws Exception
	{
			this.cookieID = cookieID;
	}	
	
	//GET's
	public String getKey()
	{
		return this.key;
	}

	public String getUserID()
	{
		return this.userID;
	}

	public long getUserSessionTimeCreation()
	{
		return this.userSessionTimeCreation;
	}	
	
	public Object getUserProperty(String key) throws Exception
	{
		if (key!=null)
			return this.userProperties.get (key);
		else
			return null;
	}

	public String getCookieID() throws Exception
	{
			return this.cookieID ;
	}	
}