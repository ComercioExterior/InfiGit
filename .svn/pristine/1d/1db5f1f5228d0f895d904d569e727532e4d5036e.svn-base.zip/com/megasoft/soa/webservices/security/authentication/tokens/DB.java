package com.megasoft.soa.webservices.security.authentication.tokens;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;


/**
*
* <b>Foundation1: </b>
*       This module provides simplified methods for database operations,
*       saving the programmer the task of coding tedious and repetitive
*       JDBC code. All methods are static, therefore they
*       can be invoked without creating an object of this class.
*	
*       @author: Yolanda Salcedo
*       
**/

public class DB
{

    /**
    * Returns a JDBC datasource object
    * @param dsName: JNDI name for the resource - example: jdbc/mydb
    */
    public static DataSource getDataSource(String dsName) throws Exception
    {

        DataSource source;

        try
        {
        
			if (dsName==null)  throw new Exception("DataSource's Name NULL; Please the for datasource configuration parameters.");
        
            Context ctx = new InitialContext();
        	source = (DataSource) ctx.lookup( dsName );
            if (null == source)
            {
                throw new Exception("JDBC DataSource not found; JNDI returned NULL");
            }
        }
        catch ( Exception e )
        {
    	   throw new Exception(e.getMessage() + " [" + dsName + "]");
        }

        return source;

    }


}
