package com.megasoft.soa.webservices.security.authentication.tokens;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.megasoft.soa.webservices.commom.WSProperties;

/*
* Implementa la obtenci�n de la Credencial del Usuario a trav�s del m�todo
* getCredential, el cual, retorna el objeto TokenCredentialBean con toda la
* informaci�n asociada al userID correspondiente.
*/

public class TokenCredentialRecovery
{

	private static DataSource dso = null;
	
	//Logger
	private static final Log log = LogFactory.getLog(TokenCredentialRecovery.class);
	
	/*
	 * Retorna las Credenciales del Usuario a trav�s del Objeto TokenCredentialBean
	 * */
	public TokenCredentialBean getCredential(String userID) throws Exception
	{
			
    	log.info("WS-Security Recuperaci�n de Credenciales en DBOracle:" );
    	
    	//Credenciales del Usuario
    	TokenCredentialBean c = null;

    	
    	
		Connection        con = null;
		PreparedStatement st  = null;
		ResultSet         rs  = null;

		//Local Cache de Datasource
		if (dso==null) dso = DB.getDataSource( WSProperties.getProperty("security-credentials-jndi") );
		
		String sql = WSProperties.getProperty("soa-ws-msc-authentication");
		
		log.debug("Buscando Usuario con Consulta:" + sql);
		//Obtiene la conexi�n a Base de Datos
		con = dso.getConnection();

	    st = con.prepareStatement(sql,ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
       						
	    // Asigna el Usuario a validar. No importa si esta activo o Inactivo. Esto es validado posteriormente
		st.setString(1, userID );

		
		//Ejecuta SQL
		rs = st.executeQuery();	
		
		try
		{
			if (rs!=null && rs.next())
			{
				log.info("Credencial Encontrada para el Usuario '" + userID + "' Canal '" + rs.getString("CANAL_CO_PASSWORDCANAL") + "').");
				
				c = new TokenCredentialBean();
				c.setUserID(userID);
				c.setUserPassword( rs.getString("CANAL_CO_PASSWORDCANAL"));
				c.setUserActive( rs.getInt("CANAL_DE_HABILITADO")==1 );
				c.setUserProperty("Date-Creation" , rs.getString("CANAL_FE_CREACION") );
				c.setUserProperty("Date-Creation" , rs.getString("CANAL_NM_NOMBRE") );
				
			}
			
			//Registra en Log la incidencia
			else
			{
				log.info("Credencial No V�lida para el Usuario: " + userID + "'");
				
			}
			
		}
		catch(Exception ex)
		{
			
			String msg = "Excepci�n validando usuario '" + userID + "' SQL[" + sql + "]. " + ex.getMessage();

			//Registra en Log la incidencia
			//WSLogTransaction.setLog( msg );
			
			throw new Exception ( msg, ex );
		}
        finally
        {
            if ( rs != null ) rs.close();
            if ( st != null ) st.close();
            if ( con!= null ) con.close();
        }
		
		return c;
	}	
}