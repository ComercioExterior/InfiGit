package com.megasoft.soa.webservices.commom;


import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.RandomAccessFile;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.Enumeration;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.log4j.Logger;

import com.megasoft.soa.webservices.security.authentication.tokens.TokenCredentialRepository;
import com.megasoft.soa.webservices.security.session.tokens.TokenSessionRepository;
import com.megasoft.utilities.interfacesAEA.ConectorAEA;

import electric.xml.Document;
import electric.xml.Element;
import electric.xml.Elements;
import electric.xml.XPath;

/*
 * Interceptor de Servicios Web-Axis
 * @author Gabriell Calatrava
 * */
public class ServletHttpCommands extends HttpServlet {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -1493564818118861015L;
	
	private static final Log log = LogFactory.getLog(ServletHttpCommands.class);
	
	public void init() throws ServletException
    {
        try{
    
          //Inicio
          System.out.println("MSC Servlet Http Commands.");
          
        }
        catch (Throwable e)
        {
        
          e.printStackTrace();
          throw new ServletException ("No se pudo iciciar correctamente la arquitectura de WebService. " + e.getMessage());

        }
    }
    
    /**
    * Carga contexto de propiedades globales para web services
    */
    private void loadAppProperties() throws Exception
    {
    
      WSProperties.init( getServletContext() );
      
    }
    
    /**
     * Carga contexto de propiedades globales para web services
     */
     private void loadingLogger() throws Exception
     {
    	 
    	 WSLogger.init(WSProperties.getProperties());
     }
    
     /*
      * Desmonta completamente el mecanismo de Log4j.
      * - Se apaga el Log con Leve=OFF
      * - Se hace shutdown del Logger
      * */
     public void unloadLogger() throws Exception
     {
    	 
    	 WSLogger.shutdown(  );
     }
 
     /* 
      * M�todo que recibe el get de un cliente para interpretar un comando
      * */
	  public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		try
		{
			
			//Procesa el comando
			processCommand( req, res);

		}
		catch(Throwable t)
		{
			System.err.println("Exception " + this.getClass().getName() + "doGet(). " + t.getMessage());
		}

	  }
	  
	/*
	 * Procesa un Comando enviado v�a HTTP
	 * */
    public void processCommand(HttpServletRequest req, HttpServletResponse res)
    {
    	//Recupera el URI que indicara el tipo de comando a ejecutar
		String URI = req.getRequestURI();
		
		String response_code="00";
		String response_description="";
		/* Recarga las propiedades de la aplicaci�n, en caso de haberse modificado el archivo manualmente y no por el m�dulo de propiedades  */
		if (URI.endsWith("/ws-config-refresh"))
		{

			res.setContentType("text/html");
			res.setHeader("Cache-Control","max-age=0");

			PrintWriter pw = null;
			
			try
			{
				 //Recarga Propiedades
				 loadAppProperties();
				 
				 pw = res.getWriter();
				 pw.print("<html><head><STYLE TYPE='text/css'><!-- .boldtable, .boldtable TD, .boldtable TH {font-family:sans-serif; font-size:10pt; color:navy; background-color:white; } --></STYLE></head>");
				 pw.print("<body><B><font face='Arial' size='2' color='blue'>Mega Soft Computaci�n.</BR> WebService Core - Versi�n Axis2 1.3</BR></B></BR>");
				 pw.print("</br>Current Date/Time:" + new java.util.Date().toString() + "</br></br>");

				 pw.print("Framework Configuration Reloaded.");
				 pw.print("</body></html>");
				 pw.flush();
				 return;
				 
			}
			catch(Exception e)
			{
				if (pw!=null)
				{
					pw.print("Configuration Reload Error.<!--" + e.getMessage() + "-->");
					pw.flush();
				}
			}
			finally
			{
				if (pw!=null) pw.close();
			}

		}
		
		/* Recarga las propiedades de la aplicaci�n, en caso de haberse modificado el archivo manualmente y no por el m�dulo de propiedades  */
		if (URI.endsWith("/ws-config-log"))
		{

			res.setContentType("text/html");
			res.setHeader("Cache-Control","max-age=0");

			PrintWriter pw = null;
			
			//Nivel a asignar al Logger
			String level = req.getParameter("level");
			
			try
			{
				 
					 pw = res.getWriter();
					 pw.print("<html><head><STYLE TYPE='text/css'><!-- .boldtable, .boldtable TD, .boldtable TH {font-family:sans-serif; font-size:10pt; color:navy; background-color:white; } --></STYLE></head>");
					 pw.print("<body><B><font face='Arial' size='2' color='blue'>Mega Soft Computaci�n.</BR> WebService Core - Versi�n Axis2 1.3</BR></B></BR>");
					 pw.print("</BR>Current Date/Time:" + new java.util.Date().toString() + "</BR></BR>");
	
					 pw.print("</BR>Framework Configuration: Logger Current Root Level:" + Logger.getRootLogger().getLevel() );
					 
					 if ( level!=null )
 					 {
						 
						 pw.print("</BR>Framework Configuration: Logger New Level: " + level);
						 WSLogger.setLevel( level );
						 
						 //pw.print("</BR>Framework Configuration: Logger Shuting Down...");
						 //WSLogger.shutdown();
					 
						 //pw.print("</BR>Framework Configuration: Starting Logger:.. ");
						 //WSLogger.init( WSProperties.getProperties() );
						 
						 pw.print("</BR>Framework Configuration: Logger reconfigured.");

 					 }

					 pw.print("</BR>Framework Configuration: Logger Posibles Levels: ALL, , TRACE, DEBUG, INFO, ERROR, FATAL, WARN, OFF" );
					 pw.print("</body></html>");
					 pw.flush();
					 
					 return;
				 
			}
			catch(Exception e)
			{
				response_code="ERROR";
				if (pw!=null)
				{
					pw.print("Configuration Reload Error.<!--" + e.getMessage() + "-->");
					pw.flush();
				}
			}
			finally
			{
				if (pw!=null) pw.close();
			}

		}
		
		/* Elimina del Cache el Usuario especificado*/
		if (URI.endsWith("/ws-security-auth"))
		{

			//Par�metros 
			String userID = req.getParameter("user");
			
			try
			{
					 if (userID!=null)
					 {
						 TokenCredentialRepository tr = new TokenCredentialRepository(); 
						 tr.removeCredential( userID );
					 }
					 response_code="OK";
					 response_description="Authentication: Removing User from Cache:" + userID;
				 
			}
			catch(Exception e)
			{
				 response_code="ERROR";
				 response_description="Command Reload Error.<!--" + e.getMessage() + "-->";
					
			}
		}
		
    
    
		/* Elimina del Cache el acceso al Usuario especificado*/
		if (URI.endsWith("/ws-security-access"))
		{
			//Par�metros 
			String userID   = req.getParameter("user");
			
			try
			{
					 if (userID!=null)
					 {
						 TokenSessionRepository tr = new TokenSessionRepository();
						 //Recupera las sesiones registradas al momento
						 Enumeration keys = tr.getRepositoryKeys();
						 
						 String id = "-" +userID + "-";
						 
						 if (keys!=null)
						 {
							 String key = null;
							 //Itera los key en busca de un key que contenga el nombre del usuario 
						     for ( ; keys.hasMoreElements() ;)
						     {
						    	 key = (String)keys.nextElement();
						    	 if ( key!=null && key.indexOf(id)>-1 )
						    	 {
						    		 //El key que contiene "-userId-"
						    		 tr.removeSession(key);
						    		 response_description+="</BR>Removing Sessions For WebService Key: " + key;
						    	 }
						     }
						 }
						 response_code="OK";
						 response_description+="</BR>Removing Sessions For WebService Key contains: " + userID;
					 }
					 
			}
			catch(Exception e)
			{
				 response_code="ERROR";
				 response_description="Command Reload Error.<!--" + e.getMessage() + "-->";
					
			}
			
		}
    
		/* Elimina del Cache todos los accesos asociados al servicio especificado*/
		if (URI.endsWith("/ws-security-service"))
		{
			//Par�metros 
			String service = req.getParameter("service");
			
			try
			{
				     
					 TokenSessionRepository tr = new TokenSessionRepository();
					 //Recupera las sesiones registradas al momento
					 Enumeration keys = tr.getRepositoryKeys();
					 
					 if ( keys!=null && service!=null ) 
					 {
						 String key = null;
						 //Itera los key en busca de Service
					     for ( ; keys.hasMoreElements() ;)
					     {
					    	 key = (String)keys.nextElement();
					    	 if ( key!=null && key.startsWith(service) )
					    	 {
					    		 tr.removeSession(key);
					    		 
					    	 }
					     }
					 }

				     response_code="OK";
				     response_description="</BR>Removing Sessions For WebService with Key start with: " + service ;

				 
			}
			catch(Exception e)
			{
				 response_code="ERROR";
				 response_description="Command Reload Error.<!--" + e.getMessage() + "-->";
					
			}
		}
		
		/* Elimina del Cache todos los accesos asociados al servicio y operaci�n especificados*/
		if (URI.endsWith("/ws-security-operation"))
		{

			
			//Par�metros 
			String service   = req.getParameter("service");
			String operation = req.getParameter("operation");
			
			try
			{
				     
					 //ELiminaci�n de Todas las sesiones pertenecientes al Servicio y Operaci�n
					 TokenSessionRepository tr = new TokenSessionRepository();
					 
					 //Recupera las sesiones registradas al momento
					 Enumeration keys = tr.getRepositoryKeys();
					 
					 //Key de b�squeda:Servicio+Operaci�n
					 String id = service + "-" + operation;
					 
					 if (keys!=null && service!=null && operation!=null)
					 {
						 String key = null;
						 //Itera los key en busca de Service y Operaciones que coincidan
					     for ( ; keys.hasMoreElements() ;)
					     {
					    	 key = (String)keys.nextElement();
					    	 if ( key!=null && key.startsWith(id) )
					    	 {
					    		 //El key comienza con el Servicio y Operaci�n descrito
					    		 tr.removeSession(key);
					    		 
					    	 }
					     }
					 }
					 response_code="OK";
					 response_description+="Removing Sessions For WebService Key: Services and operation " +id ;
					 
				 
			}
			catch(Exception e)
			{
				 response_code="ERROR";
				 response_description="Command Reload Error.<!--" + e.getMessage() + "-->";
					
			}
		}
    
		/* Muestra los keys generados y almacenados en el Cache*/
		if (URI.endsWith("/ws-security-service-sessions"))
		{

			res.setContentType("text/html");
			res.setHeader("Cache-Control","max-age=0");

			PrintWriter pw = null;
			
			//Par�metros 
			try
			{
				     
					 pw = res.getWriter();
					 pw.print("<html><head><STYLE TYPE='text/css'><!-- .boldtable, .boldtable TD, .boldtable TH {font-family:sans-serif; font-size:10pt; color:navy; background-color:white; } --></STYLE></head>");
					 pw.print("<body><B><font face='Arial' size='2' color='blue'>Mega Soft Computaci�n.</BR> WebService Core - Versi�n Axis2 1.3</BR></B></BR>");
					 pw.print("</BR>Current Date/Time:" + new java.util.Date().toString() + "</BR></BR>");
					 pw.print("</BR>Active Sessions:");
					 
					 //ELiminaci�n de Todas las sesiones pertenecientes al Servicio y Operaci�n
					 TokenSessionRepository tr = new TokenSessionRepository();
					 
					 //Recupera las sesiones registradas al momento
					 Enumeration keys = tr.getRepositoryKeys();
					 
					 if (keys!=null)
					 {
						 String key = null;
						 //Itera los key en busca de Service y Operaciones que coincidan
					     for ( int i=1 ; keys.hasMoreElements() ; i++)
					     {
					    	 key = (String)keys.nextElement();
					    		 //El key comienza con el Servicio y Operaci�n descrito
					    		 
					    		 pw.print("</BR>" + i + ".- Key:[" + key +"]");
					     }
					 }
					 
					 pw.print("</BR>Process finished.." );
					 pw.print("</body></html>");
					 pw.flush();
					 return;
				 
			}
			catch(Exception e)
			{
				if (pw!=null)
				{
					pw.print("Command Reload Error.<!--" + e.getMessage() + "-->");
					pw.flush();
				}
			}
			finally
			{
				if (pw!=null) pw.close();
			}
		}
	
		
		
		
		
		
		if (URI.endsWith("/ws-update-property"))
		{

			
			//Par�metros 
			try{
				
				String name = req.getParameter("name");
				String value= req.getParameter("value");
				
				if (name==null || value==null){
					response_code="ERROR";
					response_description = "Name or Value null";
					
				}
				else{

					updateProperty(name, value);
					response_code="OK";
					response_description="Actualizado";
				
				}
			}
			catch (Exception e) {
				e.printStackTrace();
				response_code="ERROR";
				response_description="Error " + e.getMessage();
			}
			
		}
		if (URI.endsWith("/ws-get-property"))
		{

			
				String name = req.getParameter("name");
				
				
				try {
					response_description=WSProperties.getProperty(name);
					response_code="OK";
				} catch (Exception e) {
					response_description=" Error obtienendo la propiedad "+ e.getMessage();
					response_code="ERROR";
				}
		
		}		
		
		/* Elimina del Cache todos los accesos asociados al servicio y operaci�n especificados*/
		if (URI.endsWith("/ws-security-ip"))
		{
			//Par�metros 
			String ip   = req.getParameter("ip");
			
			
			try
			{
				     
					 //ELiminaci�n de Todas las sesiones pertenecientes al Servicio y Operaci�n
					 TokenSessionRepository tr = new TokenSessionRepository();
					 
					 //Recupera las sesiones registradas al momento
					 Enumeration keys = tr.getRepositoryKeys();
					 
					 //Key de b�squeda:Servicio+Operaci�n
					 String id = ip;
					 
					 if (keys!=null && ip!=null)
					 {
						 String key = null;
						 //Itera los key en busca de Service y Operaciones que coincidan
					     for ( ; keys.hasMoreElements() ;)
					     {
					    	 key = (String)keys.nextElement();
						    	 if ( key!=null && key.indexOf(id)>-1 )
						    	 {
						    		 //El key que contiene "-userId-"
						    		 tr.removeSession(key);
						    		 
						    	 }
					    	 }
					    }
					 response_code="OK";
					 response_description+=" Removing Sessions For WebService Key: Contains IP " +id ;
				 
			}
			catch(Exception e)
			{
				 response_code="ERROR";
				 response_description="Command Reload Error.<!--" + e.getMessage() + "-->";
					
			}
		}
		
		
		/* Elimina del Cache todos los accesos asociados al servicio y operaci�n especificados*/
		if (URI.endsWith("/ws-aea-performance"))  
		{
		    String enable = req.getParameter("enable");
		    String cantidad = req.getParameter("size");
		    
		    
		    
		    if (enable!=null && enable.equalsIgnoreCase("true"))
		    	ConectorAEA.habilitarCorridasAea=true;
		    else
			ConectorAEA.habilitarCorridasAea=false;
		    
		    try{
			int cant = Integer.parseInt(cantidad);
			ConectorAEA.maximoBufferCorridasAea=cant;
		    }
		    catch (Exception e) {
			// TODO: handle exception
		    }
		    
		    
		    StringBuffer html = new StringBuffer();
		    SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss SSS");
		    
		    html.append("<html><head><STYLE TYPE='text/css'><!-- .boldtable, .boldtable TD, .boldtable TH {font-family:sans-serif; font-size:10pt; color:navy; background-color:white; } --></STYLE></head>");
		    html.append("<body><B><font face='Arial' size='2' color='blue'>Mega Soft Computaci�n.</BR> WebService Core - Versi�n Axis2 1.3</BR></B>");
		    html.append("</br>Current Date/Time:" + new java.util.Date().toString());
		    html.append("</br>Enabled?:" + ConectorAEA.habilitarCorridasAea );
		    html.append("</br>Buffer Size:" + ConectorAEA.maximoBufferCorridasAea );
			
		    
		    html.append("<br><br><center><table width='50%' border=1 cellpading=0 cellspacing=0><tr><td>Transaccion</TD><td> Tiempo de Inicio</td><td>Tiempo Total</td></tr>");
		    for (String[] registro : ConectorAEA.tiemposCorridasAea)    
		    {
			html.append("<tr><td>");
			html.append(registro[0]);
			html.append("</td><td>");
			html.append(format.format(new Date(Long.parseLong(registro[1]))));
			html.append("</td><td>");
			html.append(registro[2]);
			html.append("</td><tr>");
			
		    }
		    
		    html.append("</body></html>");
		    
		    PrintWriter pw = null;
			try {
				pw = res.getWriter();
				pw.write(html.toString());
				pw.flush();
				return;
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			finally
			{
			
				if (pw!=null) pw.close();
				
			}
		}		
		
	
		res.setContentType("text/html");
		res.setHeader("Cache-Control","max-age=0");

		PrintWriter pw = null;
		try {
			pw = res.getWriter();
			pw.print("<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?><response><response_code>" + response_code +"</response_code>");
			pw.print("<response_description><![CDATA[ " + response_description +" ]]></response_description></response>");
			pw.flush();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
		
			if (pw!=null) pw.close();
		}
    }
    
    private void updateProperty(String name, String value) throws Exception
    {
   	 
    	String filename = getServletContext().getRealPath("/WEB-INF/");
				
				//Verifica si se debe agregar un separador de rutas. Esto cubre diferencias de implementaci�n en los App. Servers
			if ( !filename.endsWith( File.separator ) ) filename += File.separator;
				
				filename += "ws_properties.xml";	
		    
			fileCopy(filename, filename+".back");
			
			Document doc = new Document(new File(filename));
		   	 
		   	 
		   	 Element root = doc.getRoot();
		   	 
		   	 int posicion = getPosition(root, name);
		   	 
		   	
		   	 XPath xpathValue = new XPath("/properties/property["+ posicion +"]/value");
			
		   	 //Asiga a cada uno de los Elementos el ValorIdMoneda correspondiente
		   	
		   	 root.getElement(xpathValue).setText(value);
		
			
		
		   	 
		   	 
		   	
		   	
			
			
			RandomAccessFile rfile=null;
			try	{
				File filetoDelete = new File(filename);
				filetoDelete.delete();
				
				// Se crea el apuntador para crear el archivo nuevamente
				rfile = new RandomAccessFile(filename,"rw");;
				rfile.writeBytes(doc.toString());
				// Se intenta cargar a ver si se creo bien
				doc = new Document(new File(filename));
				//Actualiza la propiedad en cache
				WSProperties.setProperty(name, value);
			}
			catch (Exception e) {
				// Se realiza rollbak del renombro anterior
				e.printStackTrace();
			   	 fileCopy(filename+".back", filename);
				  

				  
				
			} 
			finally{
				rfile.close();
		    }
			

	
 }
    private int getPosition(Element root, String name) throws Exception
    {

      	 String query = "/properties/property/name";
      	 
    	 XPath xPathName = new XPath(query); 
      	 Elements elProperties = root.getElements(xPathName);
      	 for (int i=0; i<elProperties.size(); i++)
      	 {
      		Element x = (Element)elProperties.nextElement();
      		 
      		if (name.equals(x.getTrimTextString()))
      		{
      			
      			return i+1;
      			
      		}
      	 }
      	 return -1;
    }
		
   private  static void fileCopy(String source, String dest) throws Exception
    {
        
        byte[] buffer = new byte[8192]; 
        int totalRead = 0; 
        BufferedInputStream input = null;
        BufferedOutputStream output = null;
                
        try
        {            

             
            try
            {
            	
                input = new BufferedInputStream(new FileInputStream(source),32000);
                output = new BufferedOutputStream(new FileOutputStream(dest));
                int bytesRead = 0;

                while (bytesRead != -1)
                {
                    bytesRead = input.read(buffer, 0, 8192);
         
                    if (bytesRead != -1)
                    {
                        totalRead = totalRead + bytesRead;
                        output.write(buffer, 0, bytesRead);
                    }
                }
            }
            catch(Exception e)
            {
             	throw new Exception("fileCopy() error - " + e.getMessage());
            }
            
        }

        finally
        {
                if (input != null)
                {
                    input.close();
                }
                if (output != null)
                {
                    output.flush();
                    output.close();
                }

        }

    }
}