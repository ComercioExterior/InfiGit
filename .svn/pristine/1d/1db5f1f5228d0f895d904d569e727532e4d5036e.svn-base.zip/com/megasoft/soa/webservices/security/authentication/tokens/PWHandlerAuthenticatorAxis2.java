package com.megasoft.soa.webservices.security.authentication.tokens;

import java.io.IOException;

import javax.security.auth.callback.Callback;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.callback.UnsupportedCallbackException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.ws.security.WSPasswordCallback;

import com.megasoft.common.cache.CacheEngine;
import com.megasoft.soa.webservices.commom.WSProperties;

 /*
  * Representa el handler de autenticaci�n para AXIS-2 1.3, Rampart 1.3 con est�ndares WS-Security.
  * El m�todo handle(..) es invocado por cada solicitud de Servicios Web efectuada al Servlet de Axis2.
  * Cada solicitud de Servicio Web env�a los Tokens de Usuario/Contrase�a en el Header del Sobre.
  * Dicho Token es validado con los existentes en el repositorio de credenciales del los servicios web.
  * El Repositorio de Credenciales (Archivo, BD, LDAP, etc.) de los Servicios web es definido por el plugin de autenticaci�n.
  */

public class PWHandlerAuthenticatorAxis2 implements CallbackHandler
{
	public static Log log = LogFactory.getLog(PWHandlerAuthenticatorAxis2.class);
    public PWHandlerAuthenticatorAxis2()
    {
	
		log.info("Constructor de Handler de Autenticaci�n.");
        user = "admin";
        pwd  = "admin";
    }

    public void handle(Callback callbacks[])
        throws IOException, UnsupportedCallbackException
    {
        
        try
    	{
        String prop = WSProperties.getProperty("my-app-property");
        log.info("Entro en la clase prop=" + prop);	 
		log.info("Entro en la clase CACHE=" + (String)CacheEngine.getObject("prueba") );	 
    	}
    		catch(Exception e)
    		{

				e.printStackTrace();
    		}
        
        log.info("Posterior al Handler Properties");
        
        for(int i = 0; i < callbacks.length; i++)
		{
			
		
            if(callbacks[i] instanceof WSPasswordCallback)
            {
                WSPasswordCallback pc = (WSPasswordCallback)callbacks[i];
                //Sistem.out.println((new StringBuffer()).append("identifier: ").append(pc.getIdentifer()).append(", usage: ").append(pc.getUsage()).toString());
                if(pc.getUsage() == 2)
                {
                    if(!user.equals(pc.getIdentifer()))
                        throw new IOException((new StringBuffer()).append("unknown user: ").append(pc.getIdentifer()).toString());
                    pc.setPassword(pwd);
                    continue;
                }
                if(pc.getUsage() != 5)
                {
                    continue;
                }
                if(!user.equals(pc.getIdentifer()))
                    throw new IOException((new StringBuffer()).append("unknown user: ").append(pc.getIdentifer()).toString());
                if(!pwd.equals(pc.getPassword()))
                    throw new IOException((new StringBuffer()).append("password incorrect for user: ").append(pc.getIdentifer()).toString());
            } else
            {
                throw new UnsupportedCallbackException(callbacks[i], "Unrecognized Callback");
            }
		}
    }

    private String user;
    private String pwd;
}