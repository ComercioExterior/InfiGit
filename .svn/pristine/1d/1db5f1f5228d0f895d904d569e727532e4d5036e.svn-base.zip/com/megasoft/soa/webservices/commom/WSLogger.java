package com.megasoft.soa.webservices.commom;


import java.util.Properties;

import org.apache.log4j.Level;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;


/**
 * Clase est�tica para gestionar la activaci�n 
 * y desactivaci�n de Log4J
 *  
 * @author Gabriell Calatrava
 */
public class WSLogger
{

	static Logger log = Logger.getLogger( WSLogger.class );
	
	/**
	 * Inicializar Logger
	 * @throws Exception
	 */
	public static void init( Properties p ) throws Exception
	{
		try
		{
			 if (p!=null)
			 {
		         /*p.setProperty("log4j.rootLogger","ALL, output");
		         p.setProperty("log4j.appender.output","org.apache.log4j.DailyRollingFileAppender");
		         p.setProperty("log4j.appender.output.Threshold","DEBUG");
		         p.setProperty("log4j.appender.output.ImmediateFlush","true");
		         p.setProperty("log4j.appender.output.layout","org.apache.log4j.PatternLayout");
		         p.setProperty("log4j.appender.output.layout.ConversionPattern","%5p %5d %c - %m%n");
		         p.setProperty("log4j.appender.output.File", "./ws_logger.log");
		         p.setProperty("log4j.appender.output.DatePattern","'.'yyyy-MM-dd");
		         */
		    	 
		         PropertyConfigurator.configure( p );
	
		         log.info("Logger Loaded and Configured.");
			 }
			 else
				 throw new Exception("Propiedades no v�lidas para Log4j.");

		}
		catch (Exception e)
		{
			System.err.println("Error iniciando Logger. " + e.getMessage() );	
			e.printStackTrace();
		}
	}

	/**
	 * Asigna una propiedad al Logger
	 * @throws Exception
	 */
	public static void setLevel( String level ) throws Exception
	{
		try
		{
			 if (level!=null)
			 {
				 //Asigna el Nivel de trazas pasado como par�ametro.
				 //Si se especifica un nivel de trazas inexistente se apaga el Logger
		         log.info("Logger setting new Level to: " + level );
				 Logger.getRootLogger().setLevel(  (Level) Level.toLevel( level , Level.OFF )  );
				 log.info("Logger setting new Level to '" + level + "'  Date:" + new java.util.Date().toString() );
				 
			 }
			 else
				 throw new Exception("Propiedad no especificada.");

		}
		catch (Exception e)
		{
			log.error("Error iniciando Logger. " + e.getMessage() , e);
				
			
		}
	}
	
	/**
	 * Detener el Logger
	 * @throws Exception
	 */
	public static void shutdown() throws Exception
	{

		try
		{
	    	 log.info("Logger Shuting Down Logger...");
	    	 
	    	 log.info("Logger Shuting Down - Setting Root Logger Level OFF");
			 Logger.getRootLogger().setLevel((Level) Level.OFF);
			 
			 log.info("Logger Shutingdown....");
	    	 LogManager.shutdown();
		}
		catch (Exception e)
		{
			System.err.println("Error cerrando Logger. " + e.getMessage() );	
			e.printStackTrace();
		}
	}
}