package com.megasoft.soa.webservices.security.authentication.tokens;

import java.util.Hashtable;

public class TokenCredentialBean
{

	//Identificador del Usuario
	private String userID            = null;
	
	// Contrase�a del Password
	private String userPassword      = null;
	
	// Indica si el Usuario esta activo(true) o inactivo(false)
	private boolean   userActive     = true;
	
	//Hasttable con propiedades particulares del usuario.
	private Hashtable userProperties = new Hashtable();
	
	//SET's
	public void setUserID(String userID)
	{
		this.userID = userID;
	}
	
	public void setUserPassword(String userPassword)
	{
		this.userPassword = userPassword;
	}	

	public void setUserActive(boolean userActive)
	{
		this.userActive = userActive;
	}	
	
	@SuppressWarnings("unchecked")
	public void setUserProperty(String key, String value) throws Exception
	{
		if (key!=null && value!=null)
			this.userProperties.put (key , value);
	}	
	
	//GET's
	public String getUserID()
	{
		return this.userID;
	}
	
	public String getUserPassword()
	{
		return this.userPassword;
	}	

	public boolean getUserActive()
	{
		return this.userActive;
	}	
	
	public Object getUserProperty(String key) throws Exception
	{
		if (key!=null)
			return this.userProperties.get (key);
		else
			return null;
	}
	
}