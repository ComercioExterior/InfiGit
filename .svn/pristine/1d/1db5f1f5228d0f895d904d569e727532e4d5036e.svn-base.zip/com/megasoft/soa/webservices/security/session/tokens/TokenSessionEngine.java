package com.megasoft.soa.webservices.security.session.tokens;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;


/*
* Gestiona todo lo relacionado a la Gesti�n de Sesi�n.
*/
public class TokenSessionEngine
{
	
	//Logger
	private static final Log log = LogFactory.getLog(TokenSessionEngine.class);

	
	/*
	 * Crea la sesi�n para una credencial de Usuario bajo es siguiente procedimiento.
	 * 1.- Verifica en el repositorio (TokenSessionRepository) de sesiones, si existe alguna activa la la credencial especificada.
	 * 2.- De existir la sesi�n retorna. FIN.
	 * 3.- De no existir la sesi�n, la crea y la guarda en el Repositorio.
	 * */
	public void createSession(String userID, String serviceName, String operationName, String ip) throws Exception
	{
		//Crea el key de cache
		StringBuffer key = new StringBuffer(100);
	
		key.append(serviceName + "-");
		key.append(operationName + "-");
		key.append(userID + "-");
		key.append(ip);
		
		//Crea punto de entrada al repositorio de sesi�n
		TokenSessionRepository sessionRepository = new TokenSessionRepository();
		
		//Verifica si la sesi�n existe en el repositorio. 
		//De No existir, la crea y la registra en el repositorio.
		if ( !sessionRepository.isSessionStored( key.toString() ) )
		{
			log.info( "Session Not found in repository for UserID = " + userID );

			//Instancia Componente para recuperaci�n de Credenciales
			TokenSessionRecovery sr = new TokenSessionRecovery();
			
			//Recupera las credenciales del Usuario		
			boolean allowedAccess = sr.isAllowed(userID , serviceName, operationName, ip);
			
			if (allowedAccess!=true)
			{
				String msg = "Acceso No permitido al Usuario[" + userID + "] Servicio[" + serviceName + "] Operaci�n[" + operationName + "] IP[" + ip + "]";
				log.info(  msg );
				throw new Exception( msg );
			}
			
			log.info( "Acceso Verificado con key [" + key + "]") ;

			TokenSessionBean sb = new TokenSessionBean();
			sb.setKey( key.toString() );
			sb.setUserID( userID );
			sb.setUserSessionTimeCreation(System.currentTimeMillis());
			
			log.info( "Agregando al Repositorio el key [" + key + "]") ;
			sessionRepository.addSession( sb );
		}
		//De existir la sesi�n en el repositorio, no hace nada y retorna.
		else
		{
			log.info( "Session Already Active in repository for UserID = " + userID  );
		}
	}
	
}