package com.megasoft.soa.webservices.commom;


import java.io.File;
import java.util.Properties;

import javax.servlet.ServletContext;

import electric.xml.Document;
import electric.xml.Element;
import electric.xml.XPath;

/**
 * PlugIns de propiedades.<br>
 * El plugin de Propiedades se configura en el archivo /WEB-INF/web.xml<br>
 * especificando la clase que implementa la recuperacion de los par�metros de la aplicacion.<br>
 * El el nombre de la clase se especifica como un Init Parameter llamado 'properties-class-name' en ActionServlet.<br>
 *
 * Este plugin retorna el valor de las propiedades encontradas en el archivo 'WEB-INF/app_properties.xml'.
 * Si la propiedad no es encontrada en dicho archivo, entonces es buscada como un context-param en web.xml.
 *  
 * @author Gabriell Calatrava
 */
public class WSPropertiesFile extends AbstractProperties
{

	ServletContext context   = null;
	Properties properties    = null;

	/**
	 * Inicializar plugin
	 * @throws Exception
	 */
	public void init(ServletContext appContext) throws Exception
	{
	
		context=appContext;
		properties = getProperties();
	}
		
	/**
     * Recupera las propiedades de la fuente de datos y las retorna en un objeto de tipo Properties
	 * @throws Exception
	 */
	public Properties getProperties() throws Exception
	{

		
		Properties appProperties = new Properties();
		String filename = context.getRealPath("/WEB-INF/");
		
		//Verifica si se debe agregar un separador de rutas. Esto cubre diferencias de implementaci�n en los App. Servers
		if ( !filename.endsWith( File.separator ) ) filename += File.separator;
		
		filename += "ws_properties.xml";
			
		try{	
			File f = new File( filename );
			
			// Compatibilidad f2-r5. Si el archivo no existe, no se procesa.
			if (f.exists())
			{
				Document doc = new Document( f );
				Element root = doc.getRoot();
				XPath xpathCount = new XPath("/properties/property");
				XPath xpathGetName = null;
				XPath xpathGetValue = null;
	
				int intCantParameters = root.getElements(xpathCount).size();
				
				for(int i=1; i <=intCantParameters ; i++)
				{
						xpathGetName= new XPath("/properties/property["+ i +"]/name");
						xpathGetValue= new XPath("/properties/property["+ i +"]/value");
						appProperties.setProperty(root.getElement(xpathGetName).getTextString(), root.getElement(xpathGetValue).getTextString());
				}
				
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw new Exception ("No se pudo cargar satisfactoriamente el archivo de propiedades '" + filename + "'. " + e.getMessage() );
		}
					
		return appProperties;
		
	}

	/**
     * Recupera el valor de la propiedad especificada.
     * Este m�todo retorna el valor de las propiedades encontradas en el archivo 'WEB-INF/app_properties.xml'
     * Si la propiedad no es encontrada en dicho archivo, entonces es buscada como un context-param en web.xml
	 * @throws Exception
	 */
	public String getProperty(String name) throws Exception 
	{

		//ValorIdMoneda de la propiedad
		String value = null;
		
		// Busca valor en el archivo de propiedades
		if (name!=null)
		{
			value = (String)properties.getProperty(name);

			//Si el valor es null intenta buscar el valor en el web.xml
			if (value==null)
			{
				value = context.getInitParameter(name);
			}
		}
		
		return value;

	}

	/**
     * Asigna el valor de la propiedad especificada.
	 * @throws Exception
	 */
	public void setProperty(String name, String value) throws Exception 
	{
		
		// Busca valor en el archivo de propiedades
		if (name!=null)
		{
			properties.setProperty(name, value);

		}
	}

}