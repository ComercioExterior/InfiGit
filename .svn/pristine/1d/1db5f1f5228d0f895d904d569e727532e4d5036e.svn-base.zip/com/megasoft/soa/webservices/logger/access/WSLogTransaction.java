package com.megasoft.soa.webservices.logger.access;

import java.sql.Timestamp;

import org.apache.log4j.Logger;

import com.megasoft.soa.webservices.commom.WSProperties;
import com.megasoft.utilities.DBOServices;

 
/*
* Graba en Base de Datos informaci�n pertinente a la transacci�n en un servicio web.
* @author Gabriell Calatrava
*/
public class WSLogTransaction
{
	//Logger
	static Logger log = Logger.getLogger( WSLogTransaction.class );
	
	/*
	 * Determina si el Logs de SoapFault esta activo o inactivo.
	 * Valores a retornar: true (Activo) , false (inactivo)
	 * */
	public static boolean isEnabled() throws Exception
	{
		//Retorna del repositorio de propiedades
		//el valor de la Propiedad que activa (true) o inactiva (false)
		// el Log de Errores.
		return WSProperties.getPropertyBoolean("log-trx-enabled");
	
	}
	 
	/* 
	 * Guarda registro de base de datos indicando Nombre del Servicio, Operaci�n y Mensaje
	 * */ 
	public static void setLogs (
								String id,  
								String estatus,
								String canal,
								String servicio,
								String operacion, 
								String sobre
							   )  
	{
		try {
			
		//Si esta habilidado el Log Se guarda la traza
			if ( isEnabled() )
			{
				
				//Revisa el sobre y extrae el usuario y password de los clientes finales
				String usuario="N/A";
				String ip="N/A";
				if (sobre!=null)
				{
					int ini=-1;
					int end =-1;

					// Se determina el inicio y fin de los tags
					ini = sobre.indexOf("&lt;consumer_ip>");
					end = sobre.indexOf("&lt;/consumer_ip>");
					
					// Si se consiguen amboas se realiza la extracion
					if ((ini>-1) && (end>-1))
						usuario = sobre.substring(ini + "&lt;consumer_ip>".length(),end); 
					
					// Si el usuario es mayor a 40 caracteres se corta.
					if (usuario.length()>40)
						usuario = usuario.substring(0,40);
					
					// Se determina el inicio y fin de los tags
					ini = sobre.indexOf("&lt;consumer_user_name>");
					end = sobre.indexOf("&lt;/consumer_user_name>");

					// Si se consiguen amboas se realiza la extracion
					if (ini>-1 && end>-1)
						ip = sobre.substring(ini +"&lt;consumer_user_name>".length(),end); 

					// Si la ip  mayor a 20 caracteres se corta.
					if (ip.length()>20)
						ip = ip.substring(0,20);
					
				}
				
				if (id==null)
					id="N/A";
				
				if (estatus==null)
					estatus="N/A";
					
				
				if (canal==null)
					canal="N/A";
				
				if (servicio==null)
					servicio="N/A";
				
				if (operacion==null)
					operacion="N/A";
				
				if (sobre==null)
					sobre="N/A";
					
				
				log.info("Log de Transacciones Activo. Message" );
				
				//Obtiene el DataSource definido como propiedad
				String dsName =WSProperties.getProperty("log-trx-jndi") ;
	
	            String sql = WSProperties.getProperty("log-transaccion-insert");
	            
				Object[] data = new Object[9];
				data[0] = estatus;
				data[1] = id;
				data[2] = canal;
				data[3] = servicio;
				data[4] = operacion;
				data[5] = sobre;
				data[6] = usuario;
				data[7] = ip;
				data[8] = new Timestamp(System.currentTimeMillis());			   
	            
			    DBOServices.executeUpdate(dsName, sql, data);
	            
			}
			//Log no activo
			else
				{
					log.info("Log de Transacciones Inactivo. Message" );
				} 
		}
		catch (Throwable e) {

			log.fatal("Excepcion General Registrando la transaccion", e);
		}
	}
    
    
}
