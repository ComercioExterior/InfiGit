package com.megasoft.soa.webservices.security.session.tokens;

import java.util.Enumeration;
import java.util.Hashtable;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/*
* Implementa la gesti�n de Sesiones de los usuarios.
* Mantiene las credenciales en un contenedor o variable est�tica.
*/
public class TokenSessionRepository
{
	//Repositorio de Sessiones
	private static Hashtable SessionRepository = new Hashtable();
	
	//Logger
	private static final Log log = LogFactory.getLog(TokenSessionRecovery.class);
	
	/*
	 * Determina si existe una sesi�n para el Key indicado.
	 * Si la Sesi�n est� presente el m�todo retorna true, de lo contrario, el m�todo retorna false. 
	 * */
	public boolean isSessionStored(String id) throws Exception
	{
		return SessionRepository.containsKey(id);
	}
	
	/*
	 * Agrega una Sesi�n indicada al Repositorio. 
	 * */
	@SuppressWarnings("unchecked")
	public void addSession( TokenSessionBean userSession ) throws Exception
	{
  		 log.info( "Agregando Sessi�n del Usuario "+ userSession.getUserID() +" al Repositorio." );
		 SessionRepository.put( userSession.getKey() ,  userSession.getUserSessionTimeCreation() );
	}	
	
	/*
	 * Retorna del Repositorio, la Sesi�n correspondiente al key especificado. 
	 * */
	public TokenSessionBean getSession( String id ) throws Exception
	{
		return (TokenSessionBean) SessionRepository.get( id );
	}	
	
	/*
	 * Remueve, del Repositorio, la Sesi�n correspondiente del UserBean especificado. 
	 * */
	public void removeSession( TokenSessionBean userSession ) throws Exception
	{
		 log.info( "Removiendo Sesi�n del Usuario "+ userSession.getUserID() +" al Repositorio." );
		 SessionRepository.remove( userSession.getUserID() );
	}
	/*
	 * Remueve, del Repositorio, la Sesi�n correspondiente del key especificado. 
	 * */
	public void removeSession( String id ) throws Exception
	{
		 log.info( "Removiendo Sesi�n del Usuario "+ id +" al Repositorio." );
		 SessionRepository.remove( id );
	}
	
	/*
	 * Remueve todas las Sesiones del Repositorio. 
	 * */
	public void emptyRepository() throws Exception
	{
		 log.info( "Vaciando Repositorio de Sesiones." );
		 SessionRepository.clear();
	}
	
	/*
	 * Remueve todas las Sesiones del Repositorio. 
	 * */
	public Enumeration getRepositoryKeys() throws Exception
	{
		 log.info( "Retornando Enumeraci�n de Sesiones registradas." );
		 return SessionRepository.keys();
	}
}