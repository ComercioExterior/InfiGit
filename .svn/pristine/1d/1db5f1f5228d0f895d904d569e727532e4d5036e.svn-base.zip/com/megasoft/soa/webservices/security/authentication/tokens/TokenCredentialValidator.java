package com.megasoft.soa.webservices.security.authentication.tokens;

/*
* Implementa el proceso de validaci�n de credenciales bajo los criterios necesarios.
*/

public class TokenCredentialValidator
{
	/*
	 * Efect�a la validaci�n de la credencial recibida representada por el Objeto TokenCredentialBean.
	 * El m�todo retorna true si la Credencial cumple con los requisitos y se considera v�lida.
	 * De lo contrario, el m�todo retorna false (Credencial No V�lida).
	 * */
	public boolean isCredentialValid(TokenCredentialBean userCredential) throws Exception
	{
		//Valida que la credencial no sea Nula
		if (userCredential==null) return false;
		
		return userCredential.getUserActive();
	}	
}