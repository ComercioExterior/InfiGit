package com.megasoft.soa.webservices.security.authentication.tokens;

import java.util.Hashtable;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/*
* Implementa el repositorio temporal para las credenciales de los usuarios.
* Mantiene las credenciales en un contenedor o variable est�tica.
*/
public class TokenCredentialRepository
{

	//Logger
	private static final Log log = LogFactory.getLog(TokenCredentialRepository.class);
	
	//Contenedor de Credenciales 
	private static Hashtable credentialRepository = new Hashtable();
	
	/*
	 * Determina si existe, en el repositorio, la credencial asociada al Usuario indicado.
	 * Si la Credencial est� presente el m�todo retorna true de lo contrario el m�todo retorna false. 
	 * */
	public boolean isCredentialStored(String userID) throws Exception
	{
		return credentialRepository.containsKey(userID);
	}
	
	/*
	 * Agrega la Credencial indicada al Repositorio. 
	 * */
	@SuppressWarnings("unchecked")
	public void addCredential( TokenCredentialBean userCredential ) throws Exception
	{
		 log.info( "Agregando Credencial del Usuario "+ userCredential.getUserID() +" al Repositorio." );
		 credentialRepository.put( userCredential.getUserID() , userCredential );
	}	
	
	/*
	 * Retorna, del Repositorio, la Credencial correspondiente al Usuario especificado. 
	 * */
	public TokenCredentialBean getCredential( String userID ) throws Exception
	{
		return (TokenCredentialBean) credentialRepository.get( userID );
	}	
	
	/*
	 * Remueve, del Repositorio, la credencial correspondiente del usuario especificado. 
	 * */
	public void removeCredential( TokenCredentialBean userCredential ) throws Exception
	{
		 log.info( "Removiendo Credencial del Usuario "+ userCredential.getUserID() +" al Repositorio." );
		 credentialRepository.remove( userCredential.getUserID() );
	}
	/*
	 * Remueve, del Repositorio, la credencial correspondiente del usuario especificado. 
	 * */
	public void removeCredential( String userID ) throws Exception
	{
		 
		 log.info( "Agregando Credencial del Usuario "+ userID +" al Repositorio." );
		 credentialRepository.remove( userID );
	}
	
	/*
	 * Remueve todas las Credenciales del Repositorio. 
	 * */
	public void emptyRepository() throws Exception
	{
		log.info( "Vaciando Repositorio Credenciales." );
		credentialRepository.clear();
	}
}