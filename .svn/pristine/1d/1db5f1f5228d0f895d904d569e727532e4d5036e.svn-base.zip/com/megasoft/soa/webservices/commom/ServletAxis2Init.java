package com.megasoft.soa.webservices.commom;


import java.io.OutputStream;

import javax.servlet.ServletException;

import org.apache.axis2.AxisFault;
import org.apache.axis2.context.MessageContext;
import org.apache.axis2.transport.http.AxisServlet;
import org.apache.log4j.Logger;

import com.megasoft.common.cache.utils.Axis2Utils;
import com.megasoft.common.cache.utils.UtilsException;
import com.megasoft.soa.webservices.logger.access.WSLogTransaction;
import com.megasoft.soa.webservices.logger.error.WSLogSoapFault;
import com.megasoft.soa.webservices.logger.performance.WSLogPerformance;

/*
 * Interceptor de Servicios Web-Axis
 * @author Gabriell Calatrava
 * */
public class ServletAxis2Init extends AxisServlet 
{

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	static Logger log = Logger.getLogger( ServletAxis2Init.class );

	public void init() throws ServletException
    {
        try{
    
          //Inicio
          log.info("MSC WebService Init.");
  
          
		  //Carga Propiedades de la Aplicaci�n          
          log.info("MSC WebService Init: Loading Properties..");
          loadAppProperties();
          log.info("MSC WebService Init: Loading Properties OK");

          //Activaci�n del Logger
          log.info("MSC WebService Init: Loading Logger");
          loadingLogger();
          log.info("MSC WebService Init: Loading Logger OK");

          //Activaci�n del Cache
          //log.info("MSC WebService Init: Loading Cache..");
          //loadCache();
          //log.info("MSC WebService Init: Loading Cache OK");
           
          //Continuaci�n de la Ejecuci�n
          super.init();
          
        }
        catch (Throwable e)
        {
          throw new ServletException ("No se pudo iniciar correctamente la arquitectura de WebService. " + e.getMessage(), e);

        }
    }
    
    /**
    * Carga contexto de propiedades globales para web services
    */
    private void loadAppProperties() throws Exception
    {
      WSProperties.init( getServletContext() );
    }
    
    /**
     * Carga contexto de propiedades globales para web services
     */
     private void loadingLogger() throws Exception
     {
    	 
    	 WSLogger.init(WSProperties.getProperties());
     }
    
     /*
      * Desmonta completamente el mecanismo de Log4j.
      * - Se apaga el Log con Leve=OFF
      * - Se hace shutdown del Logger
      * */
     public void unloadLogger() throws Exception
     {
    	 
    	 WSLogger.shutdown();
     }
   
     /*
      * Destroy del Servlet - Cleanup
      * */
     public void destroy() 
     {
    	 try{ unloadLogger(); } catch(Exception e){}
     }

    /**
     * Activa el Cache de Objetos e invoca los Pugin configurados 
     */
     public void loadCache() throws Exception
     {	

		// Realiza la lectura y ejecucion de cada uno de los cache plugings configurados en el XML, recibiendo como parametro el nombre
		// del archivo de configuracion de LOG4J
	 	//CacheEngine.startCache( getServletContext().getRealPath("/WEB-INF/cache_config.xml"), getServletContext().getRealPath("/WEB-INF/log4j.properties")  );
		
		// Coloca un objeto en cache programaticamente.
	 	//CacheEngine.setObject("prueba", "Hell WOrld");
     } 
     
 

     /*
      * M�todo encargado de la manipulaci�n del handleFault Soap.
      * */
     protected void handleFault(MessageContext messagecontext, OutputStream arg1, AxisFault axisFault) throws AxisFault 
     {
    	 try   
    	 {
    		 
    		 String canal =null;
    		 String servicio =null;
    		 String operacion =null;
    			//Verifica el valor del Canal 
    		 	try {
    				 canal = Axis2Utils.getUserPrincipal(messagecontext).getName();
    			 }catch (Exception e) {
					canal="N/A";
					}
//    			Verifica el valor del Servicio
    			 try {
    				 servicio = messagecontext.getAxisService().getName();
    			 }catch (Exception e) {
					servicio="N/A";
					}
//    			Verifica el valor de la OrdenOperacion
    			 try {
    				 operacion = messagecontext.getAxisOperation().getName().toString();
    			 }catch (Exception e) {
    				 operacion="N/A";
					}
    			 
    		 
    		 log.info( "Invocaci�n de handleFault." );
    		 //Gestiona el Log de Errores
    		 
    		 String soap_env = (String)messagecontext.getSessionContext().getProperty("request-envelope");
    		 

    		 String id = messagecontext.getLogCorrelationID().substring(9);
    		 WSLogSoapFault.setLog(id, axisFault.getMessage(), servicio, operacion, canal, UtilsException.getStringFromStackTrace(axisFault) );
    		 WSLogTransaction.setLogs(id, "0",canal,servicio, operacion, soap_env);
    		long end_time = System.currentTimeMillis(); 
      		long start_time = Long.parseLong((String)messagecontext.getSessionContext().getProperty("start-time"));
          	
    		 
    		 WSLogPerformance.setLogs(id, start_time, end_time);
    	 }
    	 catch(Throwable e)
    	 {
    		 //throw new AxisFault("Excepci�n en " + this.getClass().getName() + ".handleFault()." + e.getMessage());
    	     //log.error( "Excepci�n en " + this.getClass().getName() + ".handleFault()." , e);
    	 }
    	 
    	 
		 //Continua el flujo de ejecuci�n en Axis2
		 super.handleFault(messagecontext, arg1, axisFault);
      }
     
     
    

     
}