package com.megasoft.soa.webservices.commom;


import java.util.Properties;

import javax.servlet.ServletContext;

import org.apache.log4j.Logger;

/**
 * Clase est�tica para crear interactuar con PlugIns de propiedades.<br>
 * El plugin de Propiedades se configura en el archivo /WEB-INF/web.xml<br>
 * especificando la clase que implementa la recuperacion de los par�metros de la aplicacion.<br>
 * El el nombre de la clase se especifica como un Init Parameter llamado 'properties-class-name' en ActionServlet<br>
 *  
 * @author Gabriell Calatrava
 */
public class WSProperties
{

	static Logger log = Logger.getLogger( WSProperties.class );
	
	//Instancia del Plugin de Propiedades
	static AbstractProperties contextProperties = null;

	/**
	 * Inicializar Clase
	 * @throws Exception
	 */
	public static void init(ServletContext appContext) throws Exception
	{

		// Busca el nombre de la clase que implementa la recuperacion de propiedades de la aplicacion		
		String propertiesClassName = null;
		
		try
		{
			
			// Busca el nombre de la clase que implementa la recuperacion de propiedades de la aplicacion
			propertiesClassName = appContext.getInitParameter("properties-class-name");
			
			// En caso de no estar definida la clase, se toma como valor predefinido el del Framework
			if (propertiesClassName==null) propertiesClassName = "com.megasoft.soa.webservices.commom.WSPropertiesFile";
			
			// Instancia la Clase de Propiedades
			contextProperties = (AbstractProperties) Thread.currentThread().getContextClassLoader().loadClass(propertiesClassName).newInstance();
			
			// Inicia la carga de propiedades
			contextProperties.init(appContext);

		}
		catch (Exception io)
		{
			log.error("Error Cargando Parametros de la Aplicacion con el Plugin " + propertiesClassName);	
			io.printStackTrace();
		}

	}
		
	/**
     * Recupera el valor de la propiedad especificada
	 * @throws Exception
	 */
	
	public static String getProperty(String name) throws Exception
	{
		try
		{
			if (name!=null)
					return contextProperties.getProperty(name);
			else
					return null;

		}
		catch(Exception e)
		{
			throw new Exception ("No se pudo recuperar la Propiedad '" + name + "'. " + e.getMessage() );
			
		}
	}

	/**
     * Recupera el valor de la propiedad especificada
	 * @throws Exception
	 */
	public static boolean getPropertyBoolean(String name) throws Exception
	{
		try
		{
			if (name!=null)
			{
					return contextProperties.getProperty(name).equals("true");
			}
			else
					return false;

		}
		catch(Exception e)
		{
			throw new Exception ("No se pudo recuperar la Propiedad (Boolean) '" + name + "'. " + e.getMessage() );
			
		}
	}
	
	/**
     * Recupera las propiedades de la fuente de datos y las retorna en un objeto de tipo Properties
	 * @throws Exception
	 */
	public static Properties getProperties() throws Exception
	{
		return contextProperties.getProperties();
	}
	
	/**
     * Asigna el valor de la propiedad especificada.
	 * @throws Exception
	 */
	public static void setProperty(String name, String value) throws Exception 
	{
		
		// Busca valor en el archivo de propiedades
		if (name!=null)
		{
			log.error("XPRE:" + contextProperties.getProperty("log4j.rootLogger") );
			contextProperties.setProperty(name, value);
			log.error("XPRE:" + contextProperties.getProperty("log4j.rootLogger") );
		}
	}
}