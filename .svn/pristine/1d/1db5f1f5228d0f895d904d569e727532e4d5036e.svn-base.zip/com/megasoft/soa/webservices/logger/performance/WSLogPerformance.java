package com.megasoft.soa.webservices.logger.performance;

import org.apache.log4j.Logger;

import com.megasoft.soa.webservices.commom.WSProperties;
import com.megasoft.utilities.DBOServices;

 
/*
* Graba en Base de Datos informaci�n pertinente a la transacci�n en un servicio web.
* @author Gabriell Calatrava
*/
public class WSLogPerformance
{
	//Logger
	static Logger log = Logger.getLogger( WSLogPerformance.class );
	
	/*
	 * Determina si el Logs de SoapFault esta activo o inactivo.
	 * Valores a retornar: true (Activo) , false (inactivo)
	 * */
	public static boolean isEnabled() throws Exception
	{
		//Retorna del repositorio de propiedades
		//el valor de la Propiedad que activa (true) o inactiva (false)
		// el Log de Errores.
		return WSProperties.getPropertyBoolean("log-perform-enabled");
	
	}
	 
	/* 
	 * Guarda registro de base de datos indicando Nombre del Servicio, Operaci�n y Mensaje
	 * */ 
	public static void setLogs (
								String id,
								long start_time,
								long end_time
							
							   )  
	{
		try {
			
			
		//Si esta habilidado el Log Se guarda la traza
			if ( isEnabled() )
			{
				if (id==null)
					id="N/A";
				
	
				log.info("Log de performance Activo." );
	
				
				//Obtiene el DataSource definido como propiedad
				String dsName =WSProperties.getProperty("log-perform-jndi") ;
	
	            String sql = WSProperties.getProperty("log-performance-insert");
	            
				Object[] data = new Object[3];
				
				
				data[0] = id;
				data[1]=start_time;
				data[2]=end_time;				   		
	            
			    DBOServices.executeUpdate(dsName, sql, data);
	            
			}
			//Log no activo
			else
				{
					log.info("Log de Performance Inactivo. Message" );
				} 
		}
		catch (Throwable e) {
			log.fatal("Excepcion General Registrando el performance", e);
		}
	}
    
    
}