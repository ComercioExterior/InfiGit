package com.megasoft.soa.webservices.security.authentication.tokens;
 
import java.io.IOException;

import javax.security.auth.callback.Callback;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.callback.UnsupportedCallbackException;

import org.apache.log4j.Logger;
import org.apache.ws.security.WSPasswordCallback;

import com.megasoft.soa.webservices.commom.WSLogger;

 /*
  * Representa el handler de autenticaci�n para AXIS-2 1.3, Rampart 1.3 con est�ndares WS-Security.
  * El m�todo handle(..) es invocado por cada solicitud de Servicios Web efectuada al Servlet de Axis2.
  * Cada solicitud de Servicio Web env�a los Tokens de Usuario/Contrase�a en el Header del Sobre.
  * Dicho Token es validado con los existentes en el repositorio de credenciales del los servicios web.
  * El Repositorio de Credenciales (Archivo, BD, LDAP, etc.) de los Servicios web es definido por el plugin de autenticaci�n.
  */

public class PWHandlerAuthenticator implements CallbackHandler
{

	//Logger
	static Logger log = Logger.getLogger( WSLogger.class );
	
    public PWHandlerAuthenticator()
    {
	
    	log.info("Constructor de Handler de Autenticaci�n.");

    }

    public void handle(Callback callbacks[]) throws IOException, UnsupportedCallbackException
    {
    	try
    	{
    		
    		log.info("Handler de Callback Rampart...");

	        for(int i = 0; i < callbacks.length; i++)
			{
	        	//Verificaci�n del tipo de callback
	            if(callbacks[i] instanceof WSPasswordCallback)
	            {
	            	//Obtiene Callback Object para asignaci�n de Password
	                WSPasswordCallback pc = (WSPasswordCallback)callbacks[i];
	
	                try
	                {
		                if (pc!=null)
		                {
		                	log.info("WS-Security Handler (Token) Auth. Data: UserID [" + pc.getIdentifer() + "] Password Type [" + pc.getPasswordType() + "] Usage [" + pc.getUsage()+ "]" );
		                	
		                	TokenCredentialEngine at = new TokenCredentialEngine();	                	
		                	TokenCredentialBean userCredential = at.getCredential( pc.getIdentifer() );
							
		                	// Usuario V�lido
			                if (userCredential!=null)
			                {
			                	log.info("Usario con Credenciales activas. Se enviar� a Rampart para su autenticaci�n.");
			                	
			                	//Asignando Contrase�a plain-text a rampart para su posterior validaci�n
			            		pc.setPassword( userCredential.getUserPassword() );
	
							}
			                //Usuario No v�lido
			                else
							{
			    				throw new IOException( (new StringBuffer()).append(  "WS-Security Handler: Credenciales no v�lidas para el usuario: " ).append(pc.getIdentifer()).toString());
							}
	
						}
		            }
	                catch(Exception e)
	            	{
	                	log.error("WS-Security Handler (Token) Exception." , e);
		            	//e.printStackTrace();
		            	throw new IOException( e.getMessage() );
	            	}
	            }
	            else
	            {
	            	throw new UnsupportedCallbackException(callbacks[i], "Unrecognized Callback.");
	            }
			}
    	}
	    catch(Throwable t)
	    {
	    	throw new IOException("Unrecognized Exception." + t.getMessage());
	    }
	     
    }
}
    
