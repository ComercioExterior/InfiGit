package com.megasoft.soa.webservices.commom;

import java.util.Properties;

import javax.servlet.ServletContext;


/**
 * Superclase para crear PlugIns de propiedades.<br>
 * El plugin de Propiedades se configura en el archivo /WEB-INF/web.xml<br>
 * especificando la clase que implementa la recuperacion de los par�metros de la aplicacion.<br>
 * El el nombre de la clase se especifica en un Init Parameter llamado 'properties-class-name' en ActionServlet<br>
 *  
 * @author Gabriell Calatrava
 */
public abstract class AbstractProperties
{


	/**
	 * Inicializar plugin
	 * @throws Exception
	 */
	public abstract void init(ServletContext context) throws Exception;

		
	/**
     * Recupera las propiedades de la fuente de datos y las retorna en un objeto de tipo Properties
	 * @throws Exception
	 */
	public abstract Properties getProperties() throws Exception;
	
	/**
     * Retorna el valor de la propiedad especificada por el par�metro property
	 * @throws Exception
	 */
	public abstract String getProperty(String property) throws Exception;
	
	/**
     * Asigna el valor de la propiedad especificada.
	 * @throws Exception
	 */
	public abstract void setProperty(String name, String value) throws Exception;
	
}