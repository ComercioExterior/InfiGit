/*
 * Clase bean utilizada para almacenar la configuracion del cache
 * Autor:Nagel Camacho  
 */

package com.megasoft.common.cache.beans;

import java.util.Properties;

public class CacheConfig {

	// Nombre de la clase de plugins
	String class_name=null;
	//Identificador
	String id=null;
	// Propiedades del pluging
	Properties properties = null;
	// Fecha y hora de inicio
	String start_time=null;
	//Periodo de ejecucion
	String  period = null;

	// Verifica si esta enabled o no
	boolean  enable = false;
	
	public void setClassName(String input)
	{
		class_name= input;
	}
  
	public void setId(String input)
	{
		id =  input;
	}

	public void setProperties(Properties input)
	{
		properties= input;
	}
	
	
	
	public void setStartTime(String input)
	{
		start_time= input;
	}
	public void setPeriod(String input)
	{
		period= input;
	}

	public void setEnable(boolean input)
	{
		enable= input;
	}
	
	public String getClassName()
	{
		return class_name;
	}
	
	public String getId()
	{
		return id ;
	}
	public Properties getProperties()
	{
		return properties;
	}

	
	public String getStartTime()
	{
		return start_time;
	}
	public String getPeriod()
	{
		return period;
	}

	public boolean getEnable()
	{
		return enable;
	}
}