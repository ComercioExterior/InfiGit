/*
 *Interfaces que implementa la clase que inicia el engine de cache
 * Autor:Nagel Camacho
 */

package com.megasoft.common.cache.interfaces;

public interface InterfaceCacheEngine {

	/**
	 * Metodo encargado de iniciar el engine de cache
	 * @param cacheConfigFile Ruta del archivo que representa el "cache_config.xml"
	 * @param log4jPropertieFile Ruta del archivo properties de Log4j
	 */
	public abstract void startCache(String cacheConfigFile, String log4jPropertieFile);

	/**
	 * Metodo encargado de detener la ejecucion de un cache cuando se esta ejecutando como timer, es decir que tiene periodo configurado
	 * @param key id de la configuracion
	 */
	public abstract void stopCache(String key);
	
	/**
	 * Refresca todo la configuracion del cache
	 *
	 */
	public abstract void refreshCache();
	
	/**
	 * Ejecuta puntualmente un plugin del cache 
	 * @param key Es el id que se encuentra en el archivo de configuracion, debe ser ejecutado primero el startCache
	 */
	public abstract void startCache(String key);

	/**
	 * Borra del cache todo los objectos almacenados
	 *
	 */
	public abstract void clearCache();

	/**
	 * Coloca en el cache de manera programatica objetos
	 * @param key  Clave
	 * @param obj	Objecto
	 */
	public void setObject(String key, Object obj);
	
	/**
	 * Retorna un objecto de cache
	 *
	 * @param key Clave 
	 * @return
	 */
	public Object getObject(String key);
}