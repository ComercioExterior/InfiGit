/*
 *Interface que deben implementar los plugins para generar objectos de cache
 * Autor:Nagel Camacho
 */

package com.megasoft.common.cache.interfaces;

import java.util.Properties;

import org.apache.log4j.Logger;



public interface InterfaceCachedPlugin 
{
/**
 * Metodo el cual es invocado desde el engine con el fin de obtener el Object del plugin
 * @param log  Logger de Log4j
 * @param pro  Properties que representa la propiedades configuradas en el XML para ese plugin en particular
 * @return
 */
	public Object getObject(Logger log, Properties pro);
	
	
	
}
