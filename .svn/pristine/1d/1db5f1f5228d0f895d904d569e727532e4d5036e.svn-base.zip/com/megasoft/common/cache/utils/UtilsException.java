package com.megasoft.common.cache.utils;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;

public class UtilsException {

	
    public static String getStringFromStackTrace(Throwable th)
    {
    String stack = null;
    final Writer result = new StringWriter();
    final PrintWriter print = new PrintWriter(result); 
    
    try{
   		 th.printStackTrace(print);
   		 stack = result.toString();
   	 }
   	 catch (Exception e) {
   		stack= "Execpcion Obteniendo el StackTrace como String";
	}
   	 finally
   	 {
   		 try {
			result.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
   		 print.close();
   	 }
   	 return stack;
   	 
   	 
    }
}
