/*
 * Clase Para controlar las excepciones del Engine de Cache
 * Autor:Nagel Camacho  
 */
package com.megasoft.common.cache.exceptions;

public class CacheControlGenericException extends Exception {

	
	
	private static final long serialVersionUID = 1L;

	public CacheControlGenericException(String message)
	{
		super(message);
	}
	
}
