/*
 * Engine de Cache
 * Autor:Nagel Camacho
 * Rev: Gabriell Calatrava
 */

package com.megasoft.common.cache;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Hashtable;
import java.util.Properties;
import java.util.Timer;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.megasoft.common.cache.beans.CacheConfig;
import com.megasoft.common.cache.exceptions.CacheControlGenericException;
import com.megasoft.common.cache.handlers.RefreshCache;
import com.megasoft.common.cache.interfaces.InterfaceCachedPlugin;
import com.megasoft.common.cache.repository.CacheRepository;
import com.megasoft.common.cache.utils.TimeParserUtil;

import electric.xml.Document;
import electric.xml.Element;
import electric.xml.Elements;
import electric.xml.ParseException;
import electric.xml.XPath;

public class CacheEngine //implements InterfaceCacheEngine
{
	//Looger 
	
	private static  Logger log = Logger.getLogger( new CacheEngine().getClass() );
	
	//Almacena las referencia que los cache ejecutandose actualmente
	private static  Hashtable runnigCache=new Hashtable();
	
	// Representa el XML de configuracion
	static Document doc = null;
	
	
	//Lee el indice del archivo de configuracion para generear el bean de CacheConfig 
	private static  CacheConfig getCacheConfig(int i ) throws Exception
	{
		
		//Busca el id de la configuracion y obtiene los atributos 
		log.info("Buscando # " + i  + " de configuracion en el Archivo");
		CacheConfig config = new CacheConfig();
		log.info("Buscando # " + i  + " con XPATH cache/cache_config[" +i  +"]");
		Element el = doc.getElement(new XPath("cache/cache_config[" +i  +"]"));


		log.info("ClassName = " +el.getAttribute("classname"));
		log.info("ID = " +el.getAttribute("id"));		
		log.info("start-time= " +el.getAttribute("start-time"));
		log.info("period= " +el.getAttribute("period"));
		log.info("enable= " +el.getAttribute("enable"));

		boolean enable = false;
		
		if (el.getAttribute("classname")==null)
			throw new CacheControlGenericException("El atributo classname no puede ser nulo");
		if (el.getAttribute("id")==null)
			throw new CacheControlGenericException("El atributo id no puede ser nulo");

		if ((el.getAttribute("start-time")!=null) &&(el.getAttribute("period")==null)) 
			throw new CacheControlGenericException("El atributo period no puede ser nulo, si el start-time esta presente");

		if (el.getAttribute("enable")!=null)
			enable = el.getAttribute("enable").equalsIgnoreCase("TRUE");
			
		log.info("enable= "  +enable);

		config.setClassName(el.getAttribute("classname"));
		config.setId(el.getAttribute("id"));
		config.setProperties(getCacheProperty(i));
		config.setStartTime(el.getAttribute("start-time"));
		config.setEnable(enable);
		
		// Indica que se ejecutara como un timer
		if (el.getAttribute("period")!=null)
			config.setPeriod(el.getAttribute("period"));
		return config;
	}
	
	/**
	 * Obtiene las propiedades de cada configuracion de cache 
	 * @param i
	 * @return
	 */
	private static  Properties getCacheProperty(int i)
	{
		log.info("Buscando propiedades para # " + i  );
		Properties propertiesReturn= new Properties();
		String xpath="cache/cache_config[" +i  +"]/property";
		log.info("Buscando con el Xpath " +xpath );
		Elements el = doc.getElements(new XPath(xpath));

		// Verifica si posee propiedades
		if (el==null)
			return null;
		else
			{
				
				String xpathTemp="";
				//Busca las propiedades de cada cache
				for (int j=1; j <=el.size(); j++)
				{
					xpathTemp="cache/cache_config[" +i  +"]/property["+j+"]";
					log.info("Xpath para Obtener Propiedad " + xpathTemp);
					Element propiedad = doc.getElement(new XPath(xpathTemp));
				
					
					String name =  propiedad.getElementAt(1).getTextString();
					String value =  propiedad.getElementAt(2).getTextString();


					if (name!=null)
						{
							if (value==null)
								value="";
							propertiesReturn.setProperty(name, value);
						}
							
						
					
					log.info("Name " +name);
					log.info("Value "+ value);
				}
					
			
			}
		
		return propertiesReturn;
	}
	
	
	/**
	 * Ejecuta el plugin de cache dependiendo de la configuracion
	 * @param config
	 */
	@SuppressWarnings("unchecked")
	private static  void runCacheConfig(CacheConfig config ) throws Exception
	{
		// crea instancia de interface implementada por los plugins
		InterfaceCachedPlugin plug=null;
		
		log.info("Intentado correr " + config.getClassName() + " con Id "  +config.getId());
		
		try{
			
			if (config.getEnable()==false)
			{
				log.info("La configuracion " +config.getId() + " se tiene el atributo 'enable' en 'false'. El Plugin No ser� Ejecutado.");
			}
			// Crea la instancia dinamica del pluging
			Class Object = Class.forName(config.getClassName());
			plug = (InterfaceCachedPlugin) Object.newInstance();
		}
		catch (ClassCastException classCast) {
			log.error("ERROR",new CacheControlGenericException("Error, Clase:[" + config.getClassName() + "] puede no estar implementando la interface necesaria"));
			throw new CacheControlGenericException("Error, Clase:[" + config.getClassName() + "] puede no estar implementando la interface necesaria");
		}
		catch (ClassNotFoundException classNot) {
			log.error("ERROR", new CacheControlGenericException("Error, Clase:[" + config.getClassName() + "] no encontrada"));
			throw new CacheControlGenericException("Error, Clase:[" + config.getClassName() + "] no encontrada");
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception(e);
			
		}
		
		// Verifica si se ejecutara como timer
		if (config.getPeriod()!=null)
			{
				Timer t = new Timer();
				
				RefreshCache rcache = new RefreshCache(config, log);
				Date fechaAgenda = new Date();
				// Si se especifico una fecha con hora
				if (config.getStartTime()!=null) 
				{
					try {
						fechaAgenda = getDate(config.getStartTime());
					}
					catch (Exception e) {
						e.printStackTrace();
					}
					log.info("Iniciando con start_date");
					// Agenda la ejecucion con una fecha de inicio
					t.schedule(rcache, fechaAgenda,TimeParserUtil.parseTime(config.getPeriod()));	
				}
				else
					{
					// agenda la ejecucion solo con el periodo
					t.schedule(rcache, new Date(),TimeParserUtil.parseTime(config.getPeriod()));
					log.info("Iniciando solo con period");
					}
				
									
			
			}
		else
		{
			// Ejecuta el plugin y obtiene el objecto a guardar en cache
			Object objToCache = plug.getObject(log, config.getProperties());
			log.info("Retorno del pluging de Cache de negocio " + objToCache.toString()); 
			// Coloca del objecto retornado en cache 
			CacheRepository.repositoryGeneral.put(config.getId(), objToCache);
		}
		
	
	}
	/**
	 * Obtiene un objeto Date a partir de un String dependiento el formato
	 * @param time
	 * @return
	 * @throws Exception
	 */
	private static  Date getDate(String time) throws	Exception
	{

		// Create the date formert            
		DateFormat formatter = null; 
        Date dateReturn = new Date();
        
		/*
		 * Check for which format was provide yyyy-MM-dd HH:mm:ss,
		 * HH:mm:ss or yyy-MM-dd
		 */
		if (time.indexOf("-") > 0  && time.indexOf(":") > 0){ 
				// Full Date yyyy-MM-dd HH:mm:ss
				formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				log.info("Formateando yyyy-MM-dd HH:mm:ss" );	
		}
		else if (time.indexOf("-") > 0 && time.indexOf(":") < 0) {
			// Just the date yyyy-MM-dd
			formatter = new SimpleDateFormat("yyyy-MM-dd");
			log.info("Formateando yyyy-MM-dd" );
		} 
		else if (time.indexOf("-") < 0 && time.indexOf(":") > 0) {
			// Just a time HH:mm:ss
			log.info("Formateando HH:mm:ss" );
			formatter = new SimpleDateFormat("HH:mm:ss");
		}
        
		try {
			dateReturn = formatter.parse(time);
			
		}
		
		catch (java.text.ParseException e) {
				throw new CacheControlGenericException( "No se puede determinar el formato de fecha /hora para el formato asignado. " + time);
													
		}
		return dateReturn;
	}
	
	/**
	 * Inicia el control de cache
	 */
	public static  void startCache(String cacheConfigFile, String propertyFile)
	{
		
		try {
				
			
				PropertyConfigurator.configure(propertyFile);
				//Carga la configuracion de cache
				doc = new Document(new File(cacheConfigFile));
				
				log.info("Iniciando Control de Cache");
				log.debug(doc.toString());
				
				
				// Obtiene la cantidad de plugins configurados
				int cantCacheConfigs = (doc.getElements(new XPath("cache/cache_config"))).size();
				
				log.info("Buscando con XPATH cache/cache_config");
				
				log.info("Se encontraron configuraciones " +cantCacheConfigs + " para almacenar en cache.");
				
				// Por cada configuracion obtiene el bean y lo ejecuta
				for (int i =1; i<=cantCacheConfigs; i ++)
					{
						try{
							// Obtiene la configuracion
							CacheConfig cachecon = getCacheConfig(i);
							// Ejecuta el plugings
							runCacheConfig(cachecon);
						}
						catch (Exception e) {
							log.error("Error Cargando la configuracion de cache # " + i , e);
						}
						
					}
				}
		catch (ParseException parse) {
			log.info("No se encontr� el Documento de Configuraci�n XML '" + cacheConfigFile + " '. El Cache se activar� son la ejecuci�n de Plugin.");
		}
		catch (Exception e) {
			log.error("Error No controlado", e);
		}
	
	}
		
		
	
	public static  Object getObject(String key)
	{
		//Retorna el objecto almacenado en cache
		return CacheRepository.repositoryGeneral.get(key);
	}
	
	@SuppressWarnings("unchecked")
	public static  void setObject(String key, Object obj)
	{
		//Coloca el objecto en cache
		CacheRepository.repositoryGeneral.put(key,obj);
	}
	/**
	 * Detiene un cache que se este ejecutando como timer 
	 */
	public static  void stopCache(String key)
	{
		Timer	obj = (Timer) runnigCache.get(key);
		log.info("Cancelando key=" +key );
		obj.cancel();
	}
	
	/**
	 * Borra todo lo que se encuentre en cache
	 */
	public static  void clearCache()
	{
		CacheRepository.repositoryGeneral.clear();
	}

	public static  void clearCache(String key)
	{
		CacheRepository.repositoryGeneral.remove(key);
	}

	
	public static  void refreshCache() 
	{
		//Verifica que se haya cargado el doc anteriormente es decir que se haya ejecutado el startCahce primero
		if (doc==null)
		{
			log.error("NO se puede iniciar un refresh sin haber realizado un startCache");
			return;
		
		}
		try {
				
				//Carga la configuracion de cache
				
				log.info("Iniciando Control de Cache");
				log.debug(doc.toString());
				
				
				// Obtiene la cantidad de plugins configurados
				int cantCacheConfigs = (doc.getElements(new XPath("cache/cache_config"))).size();
				
				log.info("Buscando con XPATH cache/cache_config");
				
				log.info("Se encontraron configuraciones " +cantCacheConfigs + " para almacenar en cache");
				
				
				// Por cada configuracion obtiene el bean y lo ejecuta
				for (int i =1; i<=cantCacheConfigs; i ++)
					{
						try{
							//Obtiene la configuracion
							CacheConfig cachecon = getCacheConfig(i);
							// Ejecuta el plugings
							runCacheConfig(cachecon);
						}
						catch (Exception e) {
							log.error("Error Cargando la configuracion de cache # " + i , e);
						}
						
					}
				}
		
		catch (Exception e) {
			log.error("Error No controlado", e);
		}
	
	}


	public static  void startCache(String key) {
		// TODO Auto-generated method stub
		
		
		if (doc==null)
		{
			log.error("NO se puede iniciar un refresh sin haber realizado un startCache");
			return;
		
		}
		int x = getCacheConfiFromId(key);
		
		if (x==-1)
			{
				log.error("No Se encontro la configuracion para el ID \""+ key +"\"");
				return;
			}
		try{
			//Obtiene la configuracion
			CacheConfig cachecon = getCacheConfig(x);
			// Ejecuta el plugings
			runCacheConfig(cachecon);
		}
		catch (Exception e) {
			log.error("Error Cargando la configuracion de cache # " + x , e);
		}
		
		
		
		
		
		
	}
	/**
	 * Obtiene el indice de una configuracion en especifico, recibiendo el valor del atributo id, de no encontrar ninugna
	 * retornara -1 
	 * @param key
	 * @return
	 */
	public static  int getCacheConfiFromId(String key)
	{
		int cantCacheConfigs = (doc.getElements(new XPath("cache/cache_config"))).size();
		int intReturn=-1;
		for (int i=1; i<cantCacheConfigs;i++)
		{
			Element el = doc.getElement(new XPath("cache/cache_config[" +i  +"]"));
			if (el.getAttribute("id").equals(key))
			{
				intReturn = i;
				break;
			}
		}
		
		
		return intReturn;
	}	
	
}


