/*
 * Clase de plugin de Ejemplo
 * Autor:Nagel Camacho
 */
package com.megasoft.common.cache.plugins;


import java.util.Properties;

import org.apache.log4j.Logger;

import com.megasoft.common.cache.CacheEngine;
import com.megasoft.common.cache.interfaces.InterfaceCachedPlugin;


public class Sample1 implements InterfaceCachedPlugin {

	public Object getObject(Logger log, Properties propiedades) {
		// TODO Auto-generated method stub
		
		log.info("********************");
		
		log.info("Reloading Config " + propiedades.toString());
		return CacheEngine.getObject("prueba");
	}

	


}