package com.megasoft.common.cache.utils;

import java.util.Vector;

import org.apache.axis2.context.MessageContext;
import org.apache.ws.security.WSSecurityEngineResult;
import org.apache.ws.security.WSUsernameTokenPrincipal;
import org.apache.ws.security.handler.WSHandlerConstants;
import org.apache.ws.security.handler.WSHandlerResult;

public class Axis2Utils {

	 /*
     * Retorna el Principal del Usuario (El Principal es de Axis. No es de Servlets)
     * */
    public static WSUsernameTokenPrincipal getUserPrincipal(MessageContext messagecontext)
    {
    	
		if (messagecontext.getFLOW()==messagecontext.IN_FLOW)
		{
	
			Vector results = null;

			//Obtiene vector de Handlers
			if ((results = (Vector) messagecontext.getProperty(WSHandlerConstants.RECV_RESULTS)) == null) 
			{
				throw new RuntimeException("No security results!!");
			} 
			else 
			{	
				for (int i = 0; i < results.size(); i++)
				{ 
			            //Get hold of the WSHandlerResult instance		
			            WSHandlerResult rResult = (WSHandlerResult) results.get(i);		
	
			            Vector wsSecEngineResults = rResult.getResults();
			            
			            for (int j = 0; j < wsSecEngineResults.size(); j++) 
			            {			
					//Get hold of the WSSecurityEngineResult instance			
			                WSSecurityEngineResult wser = (WSSecurityEngineResult)wsSecEngineResults.get(j);
	
							//Extract the principal
		
							WSUsernameTokenPrincipal principal = (WSUsernameTokenPrincipal)wser.getPrincipal();
							//Get user/pass
							
							if (principal!=null)
							{
								String user = principal.getName();
								String passwd = principal.getPassword();
								return principal;
							}
			            }
				}
			}
		}
		
		return null;
    }

}
