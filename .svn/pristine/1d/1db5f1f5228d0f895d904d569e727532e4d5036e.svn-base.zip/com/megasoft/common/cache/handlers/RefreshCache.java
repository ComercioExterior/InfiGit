/*
 * Clase utilizada para invocar el plugin como un hilo, en el caso que sea como Scheduler, es decir que tenga periodo 
 * o fecha
 * Autor:Nagel Camacho  
 */
package com.megasoft.common.cache.handlers;

import java.util.Properties;
import java.util.TimerTask;

import org.apache.log4j.Logger;

import com.megasoft.common.cache.beans.CacheConfig;
import com.megasoft.common.cache.exceptions.CacheControlGenericException;
import com.megasoft.common.cache.interfaces.InterfaceCachedPlugin;
import com.megasoft.common.cache.repository.CacheRepository;


 
public class RefreshCache extends TimerTask{

	CacheConfig conf = null;
	Logger log;
	
	@SuppressWarnings("unchecked")
	public void run() {
	
		InterfaceCachedPlugin cachePlu =null;
		
		try{
			
			// Crea la instancia dinamica del plugin
			Class pluging = Class.forName(conf.getClassName());
			cachePlu  = (InterfaceCachedPlugin) pluging.newInstance();
		}
		catch (ClassCastException classCast) {
			log.error("Error de Casting",new CacheControlGenericException("Error, Clase:[" + conf.getClassName() + "] puede no estar implementando la interface necesaria"));

		}
		catch (ClassNotFoundException classNot) {
			log.error("Clase no Encontrada", new CacheControlGenericException("Error, Clase:[" + conf.getClassName()+ "] no encontrada"));

		}
		catch (Exception e) {

			log.error("Error", e);
		}
		//Ejecuta el plugin y guarda en el reporsitorio global el objecto que retorna
		CacheRepository.repositoryGeneral.put(conf.getId(),	cachePlu.getObject(log, new Properties()));
		
		
	}
	public RefreshCache(CacheConfig conf, Logger logIn) {
		this.conf = conf;
		this.log = logIn;
	}
	
}