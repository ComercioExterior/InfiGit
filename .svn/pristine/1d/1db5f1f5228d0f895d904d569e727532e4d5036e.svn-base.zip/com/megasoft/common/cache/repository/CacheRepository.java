/*
 * Repositorio global de elementos de cache
 * Autor:Nagel Camacho
 */


package com.megasoft.common.cache.repository;

import java.util.Hashtable;

public class CacheRepository {

	/**
	 * Hastable statico en el cual se coloca todo los objectos retornados por los plugins
	 * o guardado programaticamente
	 */
	public static   Hashtable repositoryGeneral = new Hashtable();
	
}
