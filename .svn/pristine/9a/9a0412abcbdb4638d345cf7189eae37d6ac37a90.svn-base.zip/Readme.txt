Nagel Camacho
06-09-2007

--------------------------------------------------------------------------------
- Archivo de Configuracion (cache_config.xml)
--------------------------------------------------------------------------------
	En este archivo se configuran los pluging que almacenaran en el cacheEngine

	Ejemplo:
	
	<cache_config id="prueba2" classname="megasoft.cachecontrol.sampleplugins.Sample2">
		<property>
			<name>s</name>
			<value>s</value>
		</property>
	</cache_config>
	 
	- Con el atributo id se almacenara la clave del objecto que retornar� el pluging
	- El classname es el nombre del pluging que se ejecutara, el cual debe retornar un Object, y el mismo recibira dos parametros un Objecto tipo
	Logger de log4j y un Properties este ultimo contienen las propiedades que se definan en el XML.
	
--------------------------------------------------------------------------------
- Iniciar el control de Cache
--------------------------------------------------------------------------------
	//Crea la instancia del Engine.
	InterfaceCacheEngine cache = new  MegaCacheControl();

	
	// Realiza la lectura y ejecucion de cada uno de los cache plugings configurados en el XML, recibiendo como parametro el nombre
	//del archivo de configuracion de LOG4J
	cache.startCache("log4j.properties");

	// Obtiene un objecto del cache bien sea colocado por el pluging o programaticamente.
	cache.getObject("prueba");

	// Coloca un objecto en cache programaticamente.
	cache.setObject("prueba", new Object());

	